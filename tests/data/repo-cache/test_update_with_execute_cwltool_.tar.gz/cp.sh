cp $1 $2
echo '_modified' >> $2