# old-datasets-v0.6.0-with-submodules

Old renku project for testing.

